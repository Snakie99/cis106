# Final Submission

## Question 1
![q1](q1_imgs/q1_1.png)
![q1](q1_imgs/q1_2.png)
![q1](q1_imgs/q1_3.png)

## Question 2
![q2](q2_imgs/q2_1.png)
![q2](q2_imgs/q2_2.png)
![q2](q2_imgs/q2_3.png)
![q2](q2_imgs/q2_4.png)
![q2](q2_imgs/q2_5.png)
![q2](q2_imgs/q2_6.png)

## Question 3
![q3](q3_imgs/q3_1.png)